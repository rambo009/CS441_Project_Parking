#include "policeparking.h"

#include "macros.h"

PoliceParking::PoliceParking()
{
    m_parkingType = POLICE_PARKING;
}
