#include "carpoolparking.h"

#include "macros.h"

CarpoolParking::CarpoolParking()
{
    m_parkingType = CARPOOL_PARKING;
}
