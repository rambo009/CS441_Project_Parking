#include "adminwindow.h"
#include "parkingspacewindow.h"
#include "ui_adminwindow.h"
#include <QDebug>
#include <QString>

adminWindow::adminWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::adminWindow)
{
    ui->setupUi(this);

     parkingSpaceWindow = new parkingspacewindow(this);
}

adminWindow::~adminWindow()
{
    delete ui;
}

void adminWindow::on_pushButton_clicked()
{
    QString contents1 = ui->lineEdit->displayText();

    QString contents2 = ui->lineEdit_2->displayText();

    //QString query = "SELECT ... " + contents1 + " cecece " + contents2 + "vrfrvr";

   qDebug() << "Contents1: " + contents1;
   qDebug() << "Contents2: " + contents2;

     parkingSpaceWindow->show();

     //Whatever is queried from the database, set values to text labels

}
