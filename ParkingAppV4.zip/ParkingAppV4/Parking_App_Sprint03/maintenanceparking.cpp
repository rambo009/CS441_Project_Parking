#include "maintenanceparking.h"

#include "macros.h"

MaintenanceParking::MaintenanceParking()
{
    m_parkingType = MAINTENANCE_PARKING;
}
