#include "handicapparking.h"

#include "macros.h"

HandicapParking::HandicapParking()
{
    m_parkingType = HANDICAP_PARKING;
}
