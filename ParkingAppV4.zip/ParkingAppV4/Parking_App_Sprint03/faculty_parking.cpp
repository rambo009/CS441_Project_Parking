#include "facultyparking.h"

#include "macros.h"

FacultyParking::FacultyParking()
{
    m_parkingType = FACULTY_PARKING;
}
