#include "regularparking.h"

#include "macros.h"

RegularParking::RegularParking()
{
    m_parkingType = REGULAR_PARKING;
}
