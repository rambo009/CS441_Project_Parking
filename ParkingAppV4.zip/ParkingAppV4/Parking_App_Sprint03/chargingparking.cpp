#include "chargingparking.h"

#include "macros.h"

ChargingParking::ChargingParking()
{
    m_parkingType = CHARGING_PARKING;
}
