#include "parkingspacewindow.h"
#include "ui_parkingspacewindow.h"

parkingspacewindow::parkingspacewindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::parkingspacewindow)
{
    ui->setupUi(this);

    //Store values from database into these fuctions

    ui->timeRemainingLabel->setText("2:15:00");
    ui->commuterTypeLabel->setText("Regular");
    ui->licenseLabel->setText("6BEX760");
}

parkingspacewindow::~parkingspacewindow()
{
    delete ui;
}
