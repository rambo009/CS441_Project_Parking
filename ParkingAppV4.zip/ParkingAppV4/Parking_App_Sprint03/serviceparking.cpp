#include "serviceparking.h"

#include "macros.h"

ServiceParking::ServiceParking()
{
    m_parkingType = SERVICE_PARKING;
}
